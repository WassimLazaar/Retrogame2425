// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2024 Advanced Micro Devices, Inc. All Rights Reserved.
// --------------------------------------------------------------------------------
// Tool Version: Vivado v.2024.1 (win64) Build 5076996 Wed May 22 18:37:14 MDT 2024
// Date        : Thu Dec 12 15:46:55 2024
// Host        : JulienPC running 64-bit major release  (build 9200)
// Command     : write_verilog -force -mode synth_stub
//               c:/ProgH/square/square.gen/sources_1/ip/clkDVIprescaler/clkDVIprescaler_stub.v
// Design      : clkDVIprescaler
// Purpose     : Stub declaration of top-level module interface
// Device      : xc7a35tcpg236-1
// --------------------------------------------------------------------------------

// This empty module with port declaration file causes synthesis tools to infer a black box for IP.
// The synthesis directives are for Synopsys Synplify support to prevent IO buffer insertion.
// Please paste the declaration into a Verilog source file or add the file as an additional source.
module clkDVIprescaler(clk_25, clk_100)
/* synthesis syn_black_box black_box_pad_pin="clk_100" */
/* synthesis syn_force_seq_prim="clk_25" */;
  output clk_25 /* synthesis syn_isclock = 1 */;
  input clk_100;
endmodule
