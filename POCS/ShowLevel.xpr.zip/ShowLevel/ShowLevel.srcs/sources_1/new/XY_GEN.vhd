library IEEE;
use IEEE.STD_LOGIC_1164.ALL;
use IEEE.NUMERIC_STD.ALL;

entity Pixel_Gen is
    Port (
        clk      : in  std_logic;
        hcount   : in  unsigned(9 downto 0); -- Horizontale teller: 0 tot 639
        vcount   : in  unsigned(9 downto 0); -- Verticale teller: 0 tot 479
        PixelAan : out std_logic;           -- Geeft aan of de pixel actief is
        rgb_out  : out std_logic_vector(11 downto 0)
    );
end Pixel_Gen;

architecture Behavioral of Pixel_Gen is

    -- De ROM heeft een adresbus die toereikend is voor 320×240 pixels, dus 17 bits (2^17 = 131072 > 76800)
    component blk_mem_gen_0 is
        Port (
            clka  : in  std_logic;
            ena   : in  std_logic;
            addra : in  std_logic_vector(16 downto 0);  -- 17-bit adres
            douta : out std_logic_vector(11 downto 0)
        );
    end component;

    -- Signalen voor de originele (ROM) coördinaten
    signal orig_h      : unsigned(8 downto 0);  -- 0 tot 319 (9 bits)
    signal orig_v      : unsigned(7 downto 0);  -- 0 tot 239 (8 bits)
    signal rom_addr_int: unsigned(16 downto 0); -- Berekening: orig_v * 320 + orig_h
    signal rom_addr    : std_logic_vector(16 downto 0);
    
    signal dout_rom    : std_logic_vector(11 downto 0);
    
begin

    -- Pixel doubling: de display-tellers worden gedeeld door 2 zodat elke ROM-pixel twee keer wordt uitgelezen
    -- Voor hcount 0 en 1 levert hcount(9 downto 1) dezelfde waarde op (0), enz.
    orig_h <= hcount(9 downto 1);  -- 640/2 = 320 kolommen
    orig_v <= vcount(8 downto 1);  -- 480/2 = 240 rijen

    -- Lineair adres: adres = (orig_v * 320) + orig_h
    rom_addr_int <= (unsigned(orig_v) * to_unsigned(320, 17)) + unsigned(orig_h);
    rom_addr <= std_logic_vector(rom_addr_int);

    ROM_inst: blk_mem_gen_0
        port map (
            clka  => clk,
            ena   => '1',
            addra => rom_addr,
            douta => dout_rom
        );

    -- Gebruik de ROM-data om de pixel aan te sturen
    process(clk)
    begin
        if rising_edge(clk) then
            if dout_rom /= "000000000000" then
                PixelAan <= '1';
                rgb_out <= dout_rom;
            else
                PixelAan <= '0';
            end if;
        end if;
    end process;

end Behavioral;
